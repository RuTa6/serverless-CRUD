const { wrapResponse } = require("../utils");

const listFrineds = async (event, context) => {
	// connct to DB

	// call db operation

    console.log("List friends called");
    return wrapResponse({
        message: "friends fetched",
        data: []
    })
};

const helloWorldPost = async (event, context) => {
	console.log("Hello World post");
	console.log(JSON.parse(event.body));
	return {
		statusCode: 200,
		body: JSON.stringify(
			{
				message: "Go Serverless v1.0! Your function executed successfully!",
				input: event,
			},
			null,
			2
		),
	};
};

module.exports = {
	listFrineds,
	helloWorldPost,
};
