const { listFrineds } = require("./friends");

module.exports = {
    listFrineds
}